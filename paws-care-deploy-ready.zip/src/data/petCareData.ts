import type { AdoptionPet, GuideArticle, PageId } from '../utils/petCareLogic';

export const IMAGES = {
  heroCompanions: '/src/assets/images/hero_companions_1795026162889.jpg',
  healthVet: '/src/assets/images/service_health_vet_1795026163778.jpg',
  nutritionBowl: '/src/assets/images/service_nutrition_bowl_1795026163643.jpg',
  groomingBath: '/src/assets/images/service_grooming_bath_1795026164359.jpg',
  adoptionDog: '/src/assets/images/adoption_dog_portrait_1795026164968.jpg',
  adoptionCat: '/src/assets/images/adoption_cat_portrait_1795026165532.jpg',
} as const;

export interface ServiceCardData {
  id: string;
  index: string;
  title: string;
  subtitle: string;
  targetPage: PageId;
  ctaLabel: string;
  image: string;
  imageAlt: string;
  points: string[];
}

export const CARE_SERVICES: ServiceCardData[] = [
  {
    id: 'health',
    index: '01',
    title: 'Pet Health & Wellness',
    subtitle: 'Preventive care routines built around early detection and calm veterinary visits.',
    targetPage: 'health',
    ctaLabel: 'Explore Health Guide',
    image: IMAGES.healthVet,
    imageAlt: 'Veterinarian gently examining a calm Beagle dog on a wooden clinic table',
    points: [
      'Core & lifestyle vaccination guidance',
      'Annual & senior routine checkup schedules',
      'Common symptom & triage checklists',
      'Year-round parasite & preventive care',
    ],
  },
  {
    id: 'nutrition',
    index: '02',
    title: 'Pet Nutrition',
    subtitle: 'Practical, portion-aware feeding habits that support energy, digestion, and longevity.',
    targetPage: 'nutrition',
    ctaLabel: 'Explore Nutrition Guide',
    image: IMAGES.nutritionBowl,
    imageAlt: 'Two matte stoneware bowls filled with fresh salmon, steamed sweet potato, and blueberries',
    points: [
      'Balanced life-stage food recommendations',
      'Whole-food toppers & hydration tips',
      'Structured daily feeding schedules',
      'Clear list of foods pets must avoid',
    ],
  },
  {
    id: 'grooming',
    index: '03',
    title: 'Grooming & Hygiene',
    subtitle: 'Low-stress home routines that keep coats healthy, nails comfortable, and teeth clean.',
    targetPage: 'grooming',
    ctaLabel: 'Explore Grooming Guide',
    image: IMAGES.groomingBath,
    imageAlt: 'Fluffy puppy wrapped in a soft sage waffle towel after a calm bath',
    points: [
      'Gentle bathing frequency & water temperature',
      'Coat-specific brushing techniques',
      'Safe step-by-step nail trimming',
      'Daily & weekly dental hygiene habits',
    ],
  },
];

export const PET_GUIDES: GuideArticle[] = [
  {
    id: 'guide-1',
    slug: 'beginners-guide-to-owning-a-pet',
    title: "Beginner's Guide to Owning a Pet",
    category: 'Beginners',
    species: 'Dogs & Cats',
    readTime: '7 min read',
    updatedAt: 'October 2026',
    reviewer: 'Reviewed by Dr. Hannah Reed, DVM',
    summary:
      'Everything first-time dog and cat guardians need to prepare before bringing a companion home—from safe spaces and veterinary setup to realistic daily routines.',
    image: IMAGES.heroCompanions,
    imageAlt: 'Golden retriever and cream tabby cat relaxing together on a linen sofa',
    keyTakeaways: [
      'Set up a quiet decompression zone before your pet arrives.',
      'Book an initial wellness check within the first 7 days.',
      'Keep feeding, sleep, and outdoor schedules consistent from day one.',
    ],
    sections: [
      {
        heading: 'Preparing a calm home environment',
        paragraphs: [
          'Whether you are welcoming an energetic puppy or an observant rescue cat, the first 72 hours shape how safe your new companion feels. Start by dedicating one quiet, draft-free corner with a washable bed, fresh water bowl, and familiar scent blanket.',
          'Before arrival day, walk your home at pet eye level. Secure trailing electrical cords, move toxic houseplants such as lilies or sago palms out of reach, and latch low kitchen cabinets storing cleaning supplies.',
        ],
        checklist: [
          'Stainless steel or ceramic water and food bowls',
          'Well-fitted harness or breakaway cat collar with ID tag',
          'Enzymatic cleaner for inevitable transition accidents',
          'Age-appropriate chew or scratching surfaces',
        ],
      },
      {
        heading: 'Establishing predictable daily rhythms',
        paragraphs: [
          'Animals thrive on gentle predictability. Aim to serve meals, offer potty breaks, and schedule short play sessions around the same windows each day. Consistency reduces anxiety far faster than constant novelty or excess stimulation.',
          'Schedule a baseline veterinary visit during your first week so your clinic can confirm microchip registration, review past vaccine records, and set up preventive parasite protection.',
        ],
      },
    ],
  },
  {
    id: 'guide-2',
    slug: 'how-to-maintain-your-pets-health',
    title: "How to Maintain Your Pet's Health",
    category: 'Health',
    species: 'Dogs & Cats',
    readTime: '6 min read',
    updatedAt: 'October 2026',
    reviewer: 'Reviewed by Dr. Hannah Reed, DVM',
    summary:
      'Build a reliable preventive health rhythm covering annual wellness exams, weight monitoring, dental care, and subtle early warning signs.',
    image: IMAGES.healthVet,
    imageAlt: 'Veterinarian checking a friendly Beagle during a calm wellness exam',
    keyTakeaways: [
      'Track resting breathing rate, appetite, and water intake weekly.',
      'Combine yearly exams with biannual visits once pets reach age seven.',
      'Never skip dental checks—oral inflammation affects overall organ health.',
    ],
    sections: [
      {
        heading: 'Preventive exams save comfort and cost',
        paragraphs: [
          'Dogs and cats instinctively mask mild discomfort. An annual physical exam lets your veterinarian listen for subtle heart murmurs, palpate lymph nodes, inspect ears, and spot early gum disease long before symptoms become obvious at home.',
          'For senior pets (typically age 7+ for dogs and 8+ for cats), shifting to twice-yearly wellness checks with routine blood panels helps catch kidney, thyroid, or joint changes early.',
        ],
        checklist: [
          'Feel ribs monthly—you should sense them under a light layer without pressing hard',
          'Keep vaccination boosters and flea/tick/heartworm preventives on calendar reminders',
          'Check ears weekly for redness, wax buildup, or sweet/yeasty odour',
        ],
      },
      {
        heading: 'Know when to seek prompt veterinary care',
        paragraphs: [
          'Sudden lethargy, repeated vomiting, laboured breathing at rest, pale gums, or straining in the litter box warrant immediate veterinary advice rather than waiting overnight.',
        ],
      },
    ],
  },
  {
    id: 'guide-3',
    slug: 'best-feeding-practices',
    title: 'Best Feeding Practices for Everyday Vitality',
    category: 'Nutrition',
    species: 'Dogs & Cats',
    readTime: '5 min read',
    updatedAt: 'September 2026',
    reviewer: 'Reviewed by Maya Lin, Companion Nutritionist',
    summary:
      'Learn how to measure portions accurately, transition foods gently without stomach upset, and balance complete diets with safe hydration.',
    image: IMAGES.nutritionBowl,
    imageAlt: 'Balanced fresh pet meal bowls with salmon, sweet potato, and blueberries',
    keyTakeaways: [
      'Measure meals with a kitchen scale or marked scoop rather than guessing.',
      'Transition between diets gradually over 7 to 10 days.',
      'Keep treats under 10% of total daily calories.',
    ],
    sections: [
      {
        heading: 'Complete nutrition starts with accurate portions',
        paragraphs: [
          'Even high-quality food can lead to gradual weight gain if bowls are topped off by eye. Check the calorie density (kcal per cup or gram) on your food label and adjust portions based on your pet’s ideal target weight and daily activity.',
          'Cats benefit particularly from moisture-rich wet meals alongside fresh water stations placed away from litter boxes, supporting urinary tract and kidney hydration.',
        ],
        checklist: [
          'Days 1–3: 75% current food, 25% new food',
          'Days 4–6: 50% current food, 50% new food',
          'Days 7–9: 25% current food, 75% new food',
          'Day 10+: 100% new food once stools remain firm',
        ],
      },
    ],
  },
  {
    id: 'guide-4',
    slug: 'dog-grooming-tips',
    title: 'Dog Grooming Tips for Stress-Free Home Care',
    category: 'Grooming',
    species: 'Dogs',
    readTime: '6 min read',
    updatedAt: 'September 2026',
    reviewer: 'Reviewed by Samira Patel, Certified Fear-Free Groomer',
    summary:
      'Practical brushing, lukewarm bathing, ear drying, and cooperative nail trimming techniques that turn grooming into calm bonding time.',
    image: IMAGES.groomingBath,
    imageAlt: 'Puppy wrapped in a sage towel after a gentle bath with wooden brushes nearby',
    keyTakeaways: [
      'Brush out tangles thoroughly before water ever touches the coat.',
      'Use pH-balanced dog shampoo and lukewarm water only.',
      'Trim nails a tiny sliver at a time paired with high-value treats.',
    ],
    sections: [
      {
        heading: 'Pre-bath brushing prevents tight matting',
        paragraphs: [
          'Water tightens existing knots in medium and double-coated breeds. Spend five calm minutes combing behind the ears, under the collar line, and along the feathering before stepping into the tub.',
          'Rinse thoroughly until water runs completely clear—leftover shampoo residue is the most common cause of post-bath itching and flaky skin.',
        ],
        checklist: [
          'Place a non-slip rubber mat inside the tub for paw stability',
          'Keep water lukewarm—similar to a baby bath temperature',
          'Towel blot gently instead of rubbing curly coats vigorously',
        ],
      },
    ],
  },
  {
    id: 'guide-5',
    slug: 'cat-care-essentials',
    title: 'Cat Care Essentials for Calm Indoor Living',
    category: 'Health',
    species: 'Cats',
    readTime: '6 min read',
    updatedAt: 'October 2026',
    reviewer: 'Reviewed by Dr. Hannah Reed, DVM',
    summary:
      'Design a rewarding indoor environment for cats—covering litter box math, vertical territory, scratching surfaces, and gentle play.',
    image: IMAGES.adoptionCat,
    imageAlt: 'Ginger and cream cat resting by a bright sunlit window',
    keyTakeaways: [
      'Follow the N+1 litter box rule: one box per cat plus one extra.',
      'Offer vertical perches near windows for natural mental enrichment.',
      'Simulate short hunt-catch-groom-sleep cycles with interactive wand play.',
    ],
    sections: [
      {
        heading: 'Designing territory your cat trusts',
        paragraphs: [
          'Indoor cats live longer, safer lives when their environment respects feline instincts. Place water bowls separate from food bowls and far away from litter trays, as cats naturally avoid drinking near elimination areas.',
          'Provide both sturdy vertical sisal posts and flat cardboard scratchers in rooms where the family gathers—scratching is healthy scent-marking and shoulder stretching, not misbehaviour.',
        ],
        checklist: [
          'Scoop litter boxes daily and wash with mild unscented soap monthly',
          'Provide 10–15 minutes of interactive feather or wand play before evening meals',
          'Use breakaway safety collars with up-to-date microchip records',
        ],
      },
    ],
  },
  {
    id: 'guide-6',
    slug: 'understanding-pet-behaviour',
    title: 'Understanding Pet Behaviour & Body Language',
    category: 'Behaviour',
    species: 'Dogs & Cats',
    readTime: '8 min read',
    updatedAt: 'August 2026',
    reviewer: 'Reviewed by Jordan Ellis, Certified Behaviour Consultant',
    summary:
      'Read subtle ear positions, tail carriage, blinking, and calming signals so you can respond with patience and build lasting mutual trust.',
    image: IMAGES.adoptionDog,
    imageAlt: 'Attentive honey-tan rescue dog sitting calmly on a cream woven rug',
    keyTakeaways: [
      'A wagging tail can mean excitement or arousal—always read the whole body.',
      'Slow blinking in cats signals relaxation and social trust.',
      'Reward desired calm behaviour immediately instead of scolding fearful reactions.',
    ],
    sections: [
      {
        heading: 'Reading the whole body, not one signal',
        paragraphs: [
          'Communication happens across ears, eyes, posture, and muscle tension together. A relaxed dog shows soft almond eyes, loose shoulders, and an effortless low-to-mid tail sweep. Lip licking, yawning when not tired, or turning the head away often signal mild overwhelm.',
          'In cats, upright ears angled slightly forward and a relaxed tail tip curve show curiosity, while flattened ears, dilated pupils in bright light, and twitching tail tips ask for personal space.',
        ],
        checklist: [
          'Give pets an uninterrupted retreat space guests and children respect',
          'Use positive reinforcement markers within 1–2 seconds of calm choices',
          'Seek a certified force-free trainer if sudden aggression or withdrawal appears',
        ],
      },
    ],
  },
];

export const ADOPTION_PETS: AdoptionPet[] = [
  {
    id: 'sample-milo',
    name: 'Milo',
    species: 'Dog',
    breed: 'Labrador & Shepherd Mix',
    age: '2 years',
    size: 'Medium (21 kg)',
    temperament: 'Gentle · Leash-trained · Housebroken',
    description:
      'Milo loves morning trail walks, puzzle feeders, and quiet afternoons curled up beside a sunny window. He settles smoothly after moderate daily exercise.',
    careNote: 'Thrives with daily 45-minute walks and predictable meal times.',
    vaccinated: true,
    microchipped: true,
    image: IMAGES.adoptionDog,
    imageAlt: 'Milo, a honey-tan mixed breed dog sitting calmly on a woven rug',
  },
  {
    id: 'sample-olive',
    name: 'Olive',
    species: 'Cat',
    breed: 'Domestic Shorthair (Ginger Tabby)',
    age: '1.5 years',
    size: 'Small (4.1 kg)',
    temperament: 'Affectionate · Window watcher · Litter-trained',
    description:
      'Olive greets mornings with soft chirps and loves perched bird-watching. She enjoys feather wand play before napping on warm wool blankets.',
    careNote: 'Best suited for a calm indoor home with tall scratching posts.',
    vaccinated: true,
    microchipped: true,
    image: IMAGES.adoptionCat,
    imageAlt: 'Olive, a ginger and cream shorthair cat sitting on a wooden bench near a window',
  },
  {
    id: 'sample-barnaby',
    name: 'Barnaby',
    species: 'Dog',
    breed: 'Beagle Mix',
    age: '4 years',
    size: 'Small-Medium (13 kg)',
    temperament: 'Curious · Friendly with dogs · Food-motivated',
    description:
      'Barnaby is an easygoing scent hound who adores sniff walks and calm car rides. He responds eagerly to positive-reinforcement training.',
    careNote: 'Needs secure fenced outdoor time or a reliable harness on walks.',
    vaccinated: true,
    microchipped: true,
    image: IMAGES.healthVet,
    imageAlt: 'Barnaby, a brown and white Beagle mix sitting calmly during a checkup',
  },
  {
    id: 'sample-clover',
    name: 'Clover',
    species: 'Cat',
    breed: 'Cream Tabby Shorthair',
    age: '3 years',
    size: 'Small (3.8 kg)',
    temperament: 'Calm · Dog-friendly · Gentle',
    description:
      'Clover enjoys sunny naps alongside respectful canine companions and quiet evenings near her favorite human.',
    careNote: 'Prefers unscented clumping litter and elevated resting shelves.',
    vaccinated: true,
    microchipped: true,
    image: IMAGES.heroCompanions,
    imageAlt: 'Clover, a cream tabby cat sleeping peacefully next to a golden dog',
  },
  {
    id: 'sample-pippin',
    name: 'Pippin',
    species: 'Dog',
    breed: 'Poodle & Terrier Mix',
    age: '10 months',
    size: 'Small (9 kg)',
    temperament: 'Playful · Smart · Low-shedding coat',
    description:
      'Pippin is an eager young learner who already knows sit, paw, and settle. He enjoys gentle brushing sessions and short agility games.',
    careNote: 'Requires regular 6–8 week coat trims and daily brushing.',
    vaccinated: true,
    microchipped: true,
    image: IMAGES.groomingBath,
    imageAlt: 'Pippin, a curly cream puppy wrapped in a soft sage towel',
  },
  {
    id: 'sample-juniper',
    name: 'Juniper',
    species: 'Cat',
    breed: 'Marmalade Shorthair',
    age: '5 years',
    size: 'Medium (4.6 kg)',
    temperament: 'Independent · Sweet-natured · Indoor cat',
    description:
      'Juniper is a composed adult cat who enjoys steady routines, brushings around her cheeks, and quiet reading company.',
    careNote: 'Ideal for apartments or calm households seeking a settled companion.',
    vaccinated: true,
    microchipped: true,
    image: IMAGES.adoptionCat,
    imageAlt: 'Juniper, a serene ginger shorthair cat sitting in natural window light',
  },
];

export const TOXIC_FOODS = [
  {
    item: 'Chocolate & Cocoa',
    risk: 'High toxicity',
    species: 'Dogs & Cats',
    note: 'Contains theobromine and caffeine, which can trigger racing heart rate, tremors, and seizures.',
  },
  {
    item: 'Grapes, Raisins & Currants',
    risk: 'Severe kidney risk',
    species: 'Dogs (avoid for cats too)',
    note: 'Even small quantities can cause sudden acute kidney injury in dogs.',
  },
  {
    item: 'Xylitol (Birch Sugar)',
    risk: 'Emergency toxicity',
    species: 'Dogs',
    note: 'Found in sugar-free gum, baked goods, and some peanut butters; causes rapid insulin drop and liver injury.',
  },
  {
    item: 'Onions, Garlic & Chives',
    risk: 'Red blood cell damage',
    species: 'Dogs & Cats',
    note: 'Raw, cooked, or powdered forms can damage red blood cells and lead to anemia (cats are extra sensitive).',
  },
  {
    item: 'Macadamia Nuts',
    risk: 'Neurological distress',
    species: 'Dogs',
    note: 'Causes hind-leg weakness, vomiting, and elevated body temperature within 12 hours.',
  },
  {
    item: 'Lilies (All Parts & Vase Water)',
    risk: 'Fatal kidney failure',
    species: 'Cats',
    note: 'Even tiny amounts of pollen licked off fur can be life-threatening for cats—keep lilies out of cat homes.',
  },
];
