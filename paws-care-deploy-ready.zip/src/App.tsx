import { useCallback, useEffect, useState } from 'react';
import {
  buildHashForRoute,
  parseRouteFromHash,
  type AdoptionPet,
  type PageId,
  type RouteState,
} from './utils/petCareLogic';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { BackToTop } from './components/BackToTop';
import { AdoptionModal } from './components/AdoptionModal';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { HealthPage } from './pages/HealthPage';
import { NutritionPage } from './pages/NutritionPage';
import { GroomingPage } from './pages/GroomingPage';
import { GuidesPage } from './pages/GuidesPage';
import { AdoptionPage } from './pages/AdoptionPage';
import { ContactPage } from './pages/ContactPage';

const PAGE_TITLES: Record<PageId, string> = {
  home: 'Paws & Care – Good Care. Great Companions.',
  about: 'About Us – Paws & Care',
  health: 'Pet Health & Wellness – Paws & Care',
  nutrition: 'Pet Nutrition & Feeding Guides – Paws & Care',
  grooming: 'Grooming & Hygiene – Paws & Care',
  guides: 'Pet Care Guides – Paws & Care',
  adoption: 'Pet Adoption (Sample Profiles) – Paws & Care',
  contact: 'Contact Us – Paws & Care',
};

export default function App() {
  const [route, setRoute] = useState<RouteState>(() =>
    parseRouteFromHash(window.location.hash),
  );
  const [selectedPet, setSelectedPet] = useState<AdoptionPet | null>(null);

  useEffect(() => {
    const onHashChange = () => {
      setRoute(parseRouteFromHash(window.location.hash));
      window.scrollTo({ top: 0, behavior: 'auto' });
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    document.title = PAGE_TITLES[route.page] ?? PAGE_TITLES.home;
  }, [route.page]);

  const navigate = useCallback((nextRoute: RouteState) => {
    const nextHash = buildHashForRoute(nextRoute);
    if (window.location.hash !== nextHash) {
      window.location.hash = nextHash;
    } else {
      setRoute(nextRoute);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF9F5] text-[#1F2421]">
      <Navbar currentPage={route.page} onNavigate={navigate} />

      <main className="flex-1">
        {route.page === 'home' && (
          <HomePage
            onNavigate={navigate}
            onSelectPetForAdoption={(pet) => setSelectedPet(pet)}
          />
        )}
        {route.page === 'about' && <AboutPage onNavigate={navigate} />}
        {route.page === 'health' && <HealthPage onNavigate={navigate} />}
        {route.page === 'nutrition' && <NutritionPage onNavigate={navigate} />}
        {route.page === 'grooming' && <GroomingPage onNavigate={navigate} />}
        {route.page === 'guides' && (
          <GuidesPage guideSlug={route.guideSlug} onNavigate={navigate} />
        )}
        {route.page === 'adoption' && (
          <AdoptionPage onSelectPetForAdoption={(pet) => setSelectedPet(pet)} />
        )}
        {route.page === 'contact' && <ContactPage />}
      </main>

      <Footer onNavigate={navigate} />
      <BackToTop />
      <AdoptionModal pet={selectedPet} onClose={() => setSelectedPet(null)} />
    </div>
  );
}
