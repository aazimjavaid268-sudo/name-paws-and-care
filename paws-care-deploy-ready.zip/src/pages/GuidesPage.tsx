import { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Search, X } from 'lucide-react';
import { PET_GUIDES } from '../data/petCareData';
import {
  filterGuides,
  type GuideCategory,
  type RouteState,
} from '../utils/petCareLogic';
import { SafeImage } from '../components/SafeImage';

interface GuidesPageProps {
  guideSlug?: string;
  onNavigate: (route: RouteState) => void;
}

const CATEGORIES: GuideCategory[] = [
  'All',
  'Beginners',
  'Health',
  'Nutrition',
  'Grooming',
  'Behaviour',
];

export function GuidesPage({ guideSlug, onNavigate }: GuidesPageProps) {
  const [selectedCategory, setSelectedCategory] = useState<GuideCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const activeArticle = guideSlug
    ? PET_GUIDES.find((g) => g.slug === guideSlug)
    : undefined;

  if (activeArticle) {
    const related = PET_GUIDES.filter((g) => g.id !== activeArticle.id).slice(0, 2);

    return (
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16 space-y-10">
        <button
          type="button"
          onClick={() => onNavigate({ page: 'guides' })}
          className="inline-flex items-center gap-2 text-sm font-semibold text-[#4E5651] hover:text-[#C85A32] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to all guides</span>
        </button>

        <header className="space-y-4">
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#6B736E]">
            <span className="font-medium text-[#5E7461]">{activeArticle.category}</span>
            <span aria-hidden="true">·</span>
            <span>{activeArticle.species}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{activeArticle.readTime}</span>
            <span aria-hidden="true">·</span>
            <span>{activeArticle.updatedAt}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421] leading-tight">
            {activeArticle.title}
          </h1>

          <p className="text-base sm:text-lg text-[#4E5651] leading-relaxed">
            {activeArticle.summary}
          </p>

          <p className="text-xs font-medium text-[#5E7461]">
            {activeArticle.reviewer}
          </p>
        </header>

        <div className="aspect-[16/9] rounded-3xl overflow-hidden border border-[#E6DFD2] bg-[#F3EDE2]">
          <SafeImage
            src={activeArticle.image}
            alt={activeArticle.imageAlt}
            loading="eager"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Key Takeaways Box */}
        <section className="bg-[#E8EFE7]/75 border border-[#D4DDD1] rounded-3xl p-6 sm:p-8 space-y-3">
          <h2 className="text-lg font-bold font-display text-[#1F2421]">
            Key Takeaways
          </h2>
          <ul className="space-y-2.5 text-sm sm:text-base text-[#1F2421]">
            {activeArticle.keyTakeaways.map((point) => (
              <li key={point} className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-[#5E7461] shrink-0 mt-1" aria-hidden="true" />
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </section>

        {/* Article Sections */}
        <div className="space-y-10">
          {activeArticle.sections.map((section) => (
            <section key={section.heading} className="space-y-4">
              <h2 className="text-2xl font-bold font-display text-[#1F2421]">
                {section.heading}
              </h2>
              {section.paragraphs.map((paragraph, idx) => (
                <p
                  key={idx}
                  className="text-base text-[#4E5651] leading-relaxed"
                >
                  {paragraph}
                </p>
              ))}
              {section.checklist && (
                <ul className="mt-4 bg-white border border-[#E6DFD2] rounded-2xl p-6 space-y-2.5 text-sm text-[#1F2421]">
                  {section.checklist.map((item) => (
                    <li key={item} className="flex items-start gap-2.5">
                      <Check
                        className="w-4 h-4 text-[#C85A32] shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>

        {/* Related Guides */}
        <section className="pt-10 border-t border-[#E6DFD2] space-y-6">
          <h2 className="text-xl font-bold font-display text-[#1F2421]">
            Continue Reading
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {related.map((item) => (
              <div
                key={item.id}
                className="bg-white border border-[#E6DFD2] rounded-2xl p-5 flex flex-col justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <p className="text-xs text-[#5E7461] font-medium">
                    {item.category} · {item.readTime}
                  </p>
                  <h3 className="text-base font-bold font-display text-[#1F2421]">
                    {item.title}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onNavigate({ page: 'guides', guideSlug: item.slug })
                  }
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#C85A32] hover:text-[#AB4722] self-start"
                >
                  <span>Read guide</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            ))}
          </div>
        </section>
      </article>
    );
  }

  const filtered = filterGuides(PET_GUIDES, selectedCategory, searchQuery);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 space-y-10">
      {/* Header */}
      <div className="space-y-4 max-w-2xl">
        <p className="text-sm font-medium text-[#5E7461]">Pet Care Guides</p>
        <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421]">
          Searchable guides for calmer, healthier pet care.
        </h1>
        <p className="text-base text-[#4E5651] leading-relaxed">
          Browse by topic or search across beginner checklists, veterinary wellness, feeding schedules, coat care, and companion behaviour.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white border border-[#E6DFD2] rounded-2xl p-4 shadow-xs">
        <div
          role="tablist"
          aria-label="Filter guides by category"
          className="flex flex-wrap items-center gap-1.5"
        >
          {CATEGORIES.map((category) => {
            const active = selectedCategory === category;
            return (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setSelectedCategory(category)}
                className={`px-3.5 py-2 text-sm font-medium rounded-xl transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#1F2421] text-white'
                    : 'text-[#4E5651] hover:bg-[#F3EDE2] hover:text-[#1F2421]'
                }`}
              >
                {category}
              </button>
            );
          })}
        </div>

        <div className="relative w-full lg:w-80">
          <label htmlFor="guide-search" className="sr-only">
            Search pet care guides
          </label>
          <Search
            className="w-4 h-4 text-[#6B736E] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            id="guide-search"
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search guides (e.g. cat, grooming)..."
            className="w-full pl-10 pr-9 py-2.5 text-sm bg-[#FBF9F5] border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              aria-label="Clear search query"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-[#6B736E] hover:text-[#1F2421]"
            >
              <X className="w-4 h-4" aria-hidden="true" />
            </button>
          )}
        </div>
      </div>

      {/* Results Count */}
      <p className="text-sm text-[#6B736E]" aria-live="polite">
        Showing <span className="font-semibold text-[#1F2421] tabular-nums">{filtered.length}</span> of{' '}
        <span className="tabular-nums">{PET_GUIDES.length}</span> guides
      </p>

      {/* Guides Grid or Empty State */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-[#E6DFD2] rounded-3xl p-12 text-center space-y-4">
          <h2 className="text-xl font-bold font-display text-[#1F2421]">
            No matching guides found
          </h2>
          <p className="text-sm text-[#4E5651] max-w-md mx-auto">
            Try clearing your search term or switching back to all categories to explore our complete library.
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="inline-flex items-center justify-center px-5 py-2.5 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
          >
            Reset filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {filtered.map((guide) => (
            <article
              key={guide.id}
              className="group flex flex-col bg-white border border-[#E6DFD2] rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-shadow duration-200"
            >
              <div className="aspect-[4/3] overflow-hidden bg-[#EFE8DC]">
                <SafeImage
                  src={guide.image}
                  alt={guide.imageAlt}
                  className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                />
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-xs text-[#6B736E] mb-2">
                  <span className="font-medium text-[#5E7461]">{guide.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{guide.species}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{guide.readTime}</span>
                </div>
                <h2 className="text-lg font-bold font-display text-[#1F2421] leading-snug">
                  {guide.title}
                </h2>
                <p className="mt-2 text-sm text-[#4E5651] leading-relaxed flex-1">
                  {guide.summary}
                </p>
                <div className="mt-5 pt-4 border-t border-[#EFE8DC]">
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate({ page: 'guides', guideSlug: guide.slug })
                    }
                    className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#C85A32] hover:text-[#AB4722] transition-colors"
                  >
                    <span>Open guide</span>
                    <ArrowRight className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
