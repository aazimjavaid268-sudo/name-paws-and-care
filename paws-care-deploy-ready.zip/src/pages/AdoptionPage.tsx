import { useState } from 'react';
import { Check, Info } from 'lucide-react';
import { ADOPTION_PETS } from '../data/petCareData';
import {
  filterPets,
  type AdoptionPet,
  type PetSpeciesFilter,
} from '../utils/petCareLogic';
import { SafeImage } from '../components/SafeImage';

interface AdoptionPageProps {
  onSelectPetForAdoption: (pet: AdoptionPet) => void;
}

const SPECIES_TABS: { label: string; value: PetSpeciesFilter }[] = [
  { label: 'All Sample Pets', value: 'All' },
  { label: 'Dogs', value: 'Dog' },
  { label: 'Cats', value: 'Cat' },
];

export function AdoptionPage({ onSelectPetForAdoption }: AdoptionPageProps) {
  const [speciesFilter, setSpeciesFilter] = useState<PetSpeciesFilter>('All');
  const pets = filterPets(ADOPTION_PETS, speciesFilter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 space-y-10">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div className="space-y-4 max-w-2xl">
          <p className="text-sm font-medium text-[#5E7461]">
            Pet Adoption · Sample Showcase
          </p>
          <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421]">
            Meet sample companions ready for caring homes.
          </h1>
          <p className="text-base text-[#4E5651] leading-relaxed">
            Browse sample dog and cat profiles showing how temperament notes, daily care needs, and veterinary status help future guardians make thoughtful matches.
          </p>
        </div>

        <div
          role="tablist"
          aria-label="Filter sample pets by species"
          className="inline-flex items-center p-1 bg-[#F3EDE2] rounded-xl self-start"
        >
          {SPECIES_TABS.map((tab) => (
            <button
              key={tab.value}
              type="button"
              role="tab"
              aria-selected={speciesFilter === tab.value}
              onClick={() => setSpeciesFilter(tab.value)}
              className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                speciesFilter === tab.value
                  ? 'bg-white text-[#1F2421] shadow-xs'
                  : 'text-[#4E5651] hover:text-[#1F2421]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Explicit Sample Data Disclaimer */}
      <div className="flex items-start gap-3 p-5 rounded-2xl bg-[#E8EFE7] border border-[#D4DDD1] text-sm text-[#1F2421] leading-relaxed">
        <Info className="w-5 h-5 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
        <div>
          <strong>Sample Content Notice:</strong> The pets listed below are demonstration profiles only and do not represent live shelter inventory. To display real adoptable animals, connect this view to a licensed shelter database or partner feed such as Petfinder API or RescueGroups.
        </div>
      </div>

      {/* Sample Pet Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
        {pets.map((pet) => (
          <article
            key={pet.id}
            className="flex flex-col bg-white border border-[#E6DFD2] rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-shadow duration-200"
          >
            <div className="aspect-[4/3] overflow-hidden bg-[#EFE8DC]">
              <SafeImage
                src={pet.image}
                alt={pet.imageAlt}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-6 flex-1 flex flex-col">
              <div className="flex items-center gap-2 text-xs text-[#6B736E] mb-1.5">
                <span className="font-medium text-[#5E7461]">Sample Profile</span>
                <span aria-hidden="true">·</span>
                <span>{pet.species}</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">{pet.age}</span>
                <span aria-hidden="true">·</span>
                <span>{pet.size}</span>
              </div>

              <h2 className="text-2xl font-bold font-display text-[#1F2421]">
                {pet.name}
              </h2>
              <p className="text-xs text-[#6B736E] mt-0.5">{pet.breed}</p>

              <p className="mt-3 text-sm text-[#4E5651] leading-relaxed">
                {pet.description}
              </p>

              <div className="mt-4 pt-4 border-t border-[#EFE8DC] space-y-2 text-xs text-[#4E5651] flex-1">
                <p>
                  <strong className="text-[#1F2421]">Temperament:</strong>{' '}
                  {pet.temperament}
                </p>
                <p>
                  <strong className="text-[#1F2421]">Care Note:</strong> {pet.careNote}
                </p>
                <div className="flex items-center gap-4 pt-1 text-[#5E7461] font-medium">
                  {pet.vaccinated && (
                    <span className="inline-flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Vaccinated</span>
                    </span>
                  )}
                  {pet.microchipped && (
                    <span className="inline-flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Microchipped</span>
                    </span>
                  )}
                </div>
              </div>

              <div className="mt-6">
                <button
                  type="button"
                  onClick={() => onSelectPetForAdoption(pet)}
                  className="w-full inline-flex items-center justify-center px-4 py-3 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
                >
                  Interested in Adoption
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
