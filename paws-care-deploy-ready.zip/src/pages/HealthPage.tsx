import { useState } from 'react';
import { AlertTriangle, ArrowRight, Check, Stethoscope } from 'lucide-react';
import { IMAGES } from '../data/petCareData';
import type { RouteState } from '../utils/petCareLogic';
import { SafeImage } from '../components/SafeImage';

interface HealthPageProps {
  onNavigate: (route: RouteState) => void;
}

const VACCINE_SCHEDULES = {
  Dog: [
    {
      stage: '8 to 16 Weeks (Puppy Series)',
      items: 'DHPP core series (distemper, parvovirus, adenovirus) every 3–4 weeks plus rabies at 12–16 weeks.',
    },
    {
      stage: '1 Year Booster',
      items: 'DHPP and rabies booster to establish multi-year immunity; discuss Bordetella or Leptospirosis based on lifestyle.',
    },
    {
      stage: 'Adult Maintenance (1 to 7 Years)',
      items: 'Core boosters every 1–3 years per veterinary guidance, plus annual heartworm testing and tick prevention.',
    },
  ],
  Cat: [
    {
      stage: '8 to 16 Weeks (Kitten Series)',
      items: 'FVRCP core series (rhinotracheitis, calicivirus, panleukopenia) plus FeLV screening and rabies vaccine.',
    },
    {
      stage: '1 Year Booster',
      items: 'FVRCP and rabies boosters; FeLV booster especially recommended for cats with outdoor or foster exposure.',
    },
    {
      stage: 'Adult Indoor Maintenance',
      items: 'Core immunity updates every 1–3 years alongside annual physical exams, weight checks, and dental grading.',
    },
  ],
};

const URGENT_SIGNS = [
  'Laboured breathing, open-mouth panting in cats, or pale/blue gums',
  'Repeated vomiting, bloated abdomen, or unproductive retching',
  'Straining to urinate without output (especially urgent in male cats)',
  'Sudden collapse, seizures, or ingestion of known toxins (lilies, xylitol, grapes)',
];

const ROUTINE_SIGNS = [
  'Mild one-time soft stool with normal energy and steady water intake',
  'Occasional ear scratching or mild waxy buildup without pain',
  'Small skin dry patch or seasonal shedding increase',
  'Subtle stiffness after long play—note timing and share at your vet checkup',
];

export function HealthPage({ onNavigate }: HealthPageProps) {
  const [species, setSpecies] = useState<'Dog' | 'Cat'>('Dog');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 space-y-16">
      {/* Page Hero */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center space-y-5">
          <p className="text-sm font-medium text-[#5E7461]">Pet Health &amp; Wellness</p>
          <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421] leading-tight">
            Preventive care keeps companions thriving longer.
          </h1>
          <p className="text-base text-[#4E5651] leading-relaxed">
            Good health care starts long before an emergency visit. Learn how vaccination timelines, quiet monthly home checks, and early symptom awareness protect your dog or cat across every stage of life.
          </p>
          <div className="pt-1 flex flex-wrap gap-4">
            <button
              type="button"
              onClick={() =>
                onNavigate({
                  page: 'guides',
                  guideSlug: 'how-to-maintain-your-pets-health',
                })
              }
              className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
            >
              <span>Read Full Health Guide</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[280px] lg:min-h-[380px] rounded-3xl overflow-hidden border border-[#E6DFD2]">
            <SafeImage
              src={IMAGES.healthVet}
              alt="Veterinarian conducting a calm checkup with a Beagle"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Interactive Vaccination Timeline */}
      <section className="bg-white border border-[#E6DFD2] rounded-3xl p-6 sm:p-10 space-y-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <p className="text-sm font-medium text-[#5E7461]">Vaccination Guidance</p>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-[#1F2421]">
              Core immunization roadmap
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Select species for vaccination schedule"
            className="inline-flex items-center p-1 bg-[#F3EDE2] rounded-xl self-start"
          >
            {(['Dog', 'Cat'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={species === tab}
                onClick={() => setSpecies(tab)}
                className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  species === tab
                    ? 'bg-white text-[#1F2421] shadow-xs'
                    : 'text-[#4E5651] hover:text-[#1F2421]'
                }`}
              >
                {tab}s
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {VACCINE_SCHEDULES[species].map((step) => (
            <div
              key={step.stage}
              className="p-6 rounded-2xl bg-[#FBF9F5] border border-[#E6DFD2] space-y-2.5"
            >
              <h3 className="text-base font-bold font-display text-[#1F2421]">
                {step.stage}
              </h3>
              <p className="text-sm text-[#4E5651] leading-relaxed">{step.items}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Symptom Triage Reference */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-7">
        <div className="bg-[#FDF4F1] border border-[#F0D4CA] rounded-3xl p-7 space-y-4">
          <div className="flex items-center gap-2.5 text-[#AB4722]">
            <AlertTriangle className="w-5 h-5 shrink-0" aria-hidden="true" />
            <h2 className="text-xl font-bold font-display">
              Seek Immediate Vet Care
            </h2>
          </div>
          <p className="text-sm text-[#4E5651]">
            Contact an emergency clinic right away if you notice any of these signs:
          </p>
          <ul className="space-y-3 text-sm text-[#1F2421]">
            {URGENT_SIGNS.map((sign) => (
              <li key={sign} className="flex items-start gap-2.5">
                <span className="font-bold text-[#C85A32]" aria-hidden="true">
                  •
                </span>
                <span>{sign}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-[#E8EFE7]/75 border border-[#D4DDD1] rounded-3xl p-7 space-y-4">
          <div className="flex items-center gap-2.5 text-[#5E7461]">
            <Stethoscope className="w-5 h-5 shrink-0" aria-hidden="true" />
            <h2 className="text-xl font-bold font-display text-[#1F2421]">
              Monitor &amp; Book Routine Checkup
            </h2>
          </div>
          <p className="text-sm text-[#4E5651]">
            Track timing and appetite closely, and schedule a regular clinic appointment if persistent:
          </p>
          <ul className="space-y-3 text-sm text-[#1F2421]">
            {ROUTINE_SIGNS.map((sign) => (
              <li key={sign} className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
                <span>{sign}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
