import { useState } from 'react';
import { AlertCircle, ArrowRight, Check } from 'lucide-react';
import { IMAGES, TOXIC_FOODS } from '../data/petCareData';
import type { RouteState } from '../utils/petCareLogic';
import { SafeImage } from '../components/SafeImage';

interface NutritionPageProps {
  onNavigate: (route: RouteState) => void;
}

const FEEDING_SCHEDULES = {
  Dog: [
    {
      stage: 'Puppies (8 Weeks to 6 Months)',
      frequency: '3–4 small meals daily',
      note: 'Supports steady blood sugar and rapid bone growth with puppy-formulated protein and calcium ratios.',
    },
    {
      stage: 'Adult Dogs (1 to 7 Years)',
      frequency: '2 measured meals daily',
      note: 'Morning and evening portions prevent hunger bile nausea and help maintain healthy body condition.',
    },
    {
      stage: 'Senior Dogs (7+ Years)',
      frequency: '2 gentle meals daily',
      note: 'Prioritize highly digestible proteins, omega-3 fatty acids, and careful calorie tracking as activity slows.',
    },
  ],
  Cat: [
    {
      stage: 'Kittens (8 Weeks to 6 Months)',
      frequency: '3–4 wet/dry meals daily',
      note: 'Growing kittens burn high energy per kilogram; wet food helps establish healthy hydration early.',
    },
    {
      stage: 'Adult Cats (1 to 8 Years)',
      frequency: '2–3 measured meals daily',
      note: 'Small frequent meals align with feline natural hunting rhythms; keep fresh water away from food bowls.',
    },
    {
      stage: 'Senior Cats (8+ Years)',
      frequency: '3–4 small moisture-rich meals',
      note: 'Warm wet food slightly to enhance aroma and support kidney hydration and lean muscle maintenance.',
    },
  ],
};

export function NutritionPage({ onNavigate }: NutritionPageProps) {
  const [species, setSpecies] = useState<'Dog' | 'Cat'>('Dog');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 space-y-16">
      {/* Intro Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center space-y-5">
          <p className="text-sm font-medium text-[#5E7461]">Pet Nutrition</p>
          <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421] leading-tight">
            Balanced bowls for steady energy and gut comfort.
          </h1>
          <p className="text-base text-[#4E5651] leading-relaxed">
            Every dog and cat thrives on complete, bioavailable nutrition matched to their age, size, and activity level. Use our practical feeding schedules, safe topper ideas, and toxic food reference to feed with confidence.
          </p>
          <div className="pt-1 flex flex-wrap gap-4">
            <button
              type="button"
              onClick={() =>
                onNavigate({ page: 'guides', guideSlug: 'best-feeding-practices' })
              }
              className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
            >
              <span>Read Feeding Practices Guide</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[280px] lg:min-h-[380px] rounded-3xl overflow-hidden border border-[#E6DFD2]">
            <SafeImage
              src={IMAGES.nutritionBowl}
              alt="Fresh pet nutrition in stoneware bowls with salmon, sweet potato, and blueberries"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Feeding Schedule Section */}
      <section className="bg-white border border-[#E6DFD2] rounded-3xl p-6 sm:p-10 space-y-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <p className="text-sm font-medium text-[#5E7461]">Feeding Schedules</p>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-[#1F2421]">
              Recommended meal rhythm by life stage
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Select species for feeding schedule"
            className="inline-flex items-center p-1 bg-[#F3EDE2] rounded-xl self-start"
          >
            {(['Dog', 'Cat'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={species === tab}
                onClick={() => setSpecies(tab)}
                className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  species === tab
                    ? 'bg-white text-[#1F2421] shadow-xs'
                    : 'text-[#4E5651] hover:text-[#1F2421]'
                }`}
              >
                {tab}s
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {FEEDING_SCHEDULES[species].map((row) => (
            <div
              key={row.stage}
              className="p-6 rounded-2xl bg-[#FBF9F5] border border-[#E6DFD2] space-y-2.5"
            >
              <p className="text-xs font-medium text-[#C85A32]">{row.frequency}</p>
              <h3 className="text-base font-bold font-display text-[#1F2421]">
                {row.stage}
              </h3>
              <p className="text-sm text-[#4E5651] leading-relaxed">{row.note}</p>
            </div>
          ))}
        </div>

        <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-[#4E5651]">
          <div className="flex items-start gap-2.5">
            <Check className="w-4 h-4 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              <strong>Safe Whole-Food Toppers:</strong> Plain steamed pumpkin, blueberries, cooked plain salmon, and unsalted green beans (keep toppers under 10% of daily calories).
            </span>
          </div>
          <div className="flex items-start gap-2.5">
            <Check className="w-4 h-4 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              <strong>Hydration Standard:</strong> Refresh water bowls daily with ceramic or stainless steel dishes to avoid plastic chin acne in cats.
            </span>
          </div>
        </div>
      </section>

      {/* Foods Pets Must Avoid */}
      <section className="space-y-6">
        <div className="space-y-2 max-w-2xl">
          <p className="text-sm font-medium text-[#C85A32]">Kitchen Safety Reference</p>
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-[#1F2421]">
            Common foods &amp; plants pets must avoid
          </h2>
          <p className="text-sm sm:text-base text-[#4E5651]">
            Keep these everyday household items safely stored away from curious paws and noses.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {TOXIC_FOODS.map((entry) => (
            <div
              key={entry.item}
              className="bg-white border border-[#E6DFD2] rounded-2xl p-6 space-y-2.5 shadow-xs"
            >
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="font-semibold text-[#AB4722] inline-flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{entry.risk}</span>
                </span>
                <span className="text-[#6B736E]">{entry.species}</span>
              </div>
              <h3 className="text-base font-bold font-display text-[#1F2421]">
                {entry.item}
              </h3>
              <p className="text-sm text-[#4E5651] leading-relaxed">{entry.note}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
