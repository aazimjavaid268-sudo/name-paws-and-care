import { ArrowRight, Check, Info } from 'lucide-react';
import {
  ADOPTION_PETS,
  CARE_SERVICES,
  IMAGES,
  PET_GUIDES,
} from '../data/petCareData';
import type { AdoptionPet, RouteState } from '../utils/petCareLogic';
import { SafeImage } from '../components/SafeImage';

interface HomePageProps {
  onNavigate: (route: RouteState) => void;
  onSelectPetForAdoption: (pet: AdoptionPet) => void;
}

const TRUST_INDICATORS = [
  { label: 'Core Care Disciplines', value: '3 Pillars' },
  { label: 'Editorial Guides', value: '6 In-Depth' },
  { label: 'Veterinary Review', value: '100% Checked' },
  { label: 'Toxic Food Alerts', value: 'Clear Safety' },
];

export function HomePage({
  onNavigate,
  onSelectPetForAdoption,
}: HomePageProps) {
  const featuredGuides = PET_GUIDES.slice(0, 3);
  const featuredPets = ADOPTION_PETS.slice(0, 3);

  const scrollToServices = () => {
    const el = document.getElementById('pet-care-services');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-12 lg:pt-16 lg:pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          {/* Editorial Copy */}
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            <p className="text-sm font-medium text-[#5E7461]">
              Everyday Pet Health · Nutrition · Gentle Grooming
            </p>

            <h1 className="text-4xl sm:text-5xl lg:text-[3.5rem] font-extrabold font-display tracking-tight text-[#1F2421] leading-[1.08]">
              Good Care. Great Companions.
            </h1>

            <p className="text-base sm:text-lg text-[#4E5651] leading-relaxed max-w-xl">
              Paws &amp; Care brings calm, practical veterinary guidance, balanced feeding routines, and force-free grooming habits together in one trusted resource for dog and cat guardians.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-1">
              <button
                type="button"
                onClick={scrollToServices}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl shadow-xs transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C85A32]"
              >
                <span>Explore Pet Care</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate({ page: 'guides' })}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#1F2421] bg-white border border-[#D8CFC0] hover:border-[#C85A32]/50 hover:bg-[#F3EDE2]/60 rounded-xl transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C85A32]"
              >
                <span>Discover Our Guides</span>
              </button>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs font-medium text-[#6B736E]">
              <span>Vet-reviewed checklists</span>
              <span aria-hidden="true" className="hidden sm:inline">·</span>
              <span>Dogs &amp; indoor cats</span>
              <span aria-hidden="true" className="hidden sm:inline">·</span>
              <span>Clear emergency food warnings</span>
            </div>
          </div>

          {/* Dominant Visual Carrier */}
          <div className="lg:col-span-6">
            <div className="h-full min-h-[300px] sm:min-h-[380px] lg:min-h-[460px] rounded-3xl overflow-hidden border border-[#E6DFD2] bg-[#F3EDE2] shadow-sm">
              <SafeImage
                src={IMAGES.heroCompanions}
                alt="Happy golden dog and calm cream tabby cat resting together on a linen sofa by a sunlit window"
                loading="eager"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Trust Strip */}
        <div className="mt-10 lg:mt-14 pt-8 border-t border-[#E6DFD2] grid grid-cols-2 lg:grid-cols-4 gap-6">
          {TRUST_INDICATORS.map((item) => (
            <div key={item.label} className="space-y-1">
              <p className="text-xl sm:text-2xl font-bold font-display text-[#1F2421] tabular-nums">
                {item.value}
              </p>
              <p className="text-xs sm:text-sm text-[#6B736E]">{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pet Care Services Section */}
      <section
        id="pet-care-services"
        className="bg-[#F3EDE2]/75 border-y border-[#E6DFD2] py-16 lg:py-24"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="space-y-3 max-w-2xl">
              <p className="text-sm font-medium text-[#5E7461]">
                Core Pet Care Pillars
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold font-display tracking-tight text-[#1F2421]">
                Structured care built for everyday life
              </h2>
            </div>
            <p className="text-sm sm:text-base text-[#4E5651] max-w-md">
              Explore dedicated playbooks for preventive wellness, whole-bowl nutrition, and calm at-home grooming.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
            {CARE_SERVICES.map((service) => (
              <article
                key={service.id}
                className="group flex flex-col bg-white border border-[#E6DFD2] rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-shadow duration-200"
              >
                <div className="aspect-[4/3] overflow-hidden bg-[#EFE8DC]">
                  <SafeImage
                    src={service.image}
                    alt={service.imageAlt}
                    className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                  />
                </div>

                <div className="p-6 sm:p-7 flex-1 flex flex-col">
                  <p className="text-xs font-medium text-[#6B736E] tabular-nums mb-1.5">
                    {service.index}. Care Pillar
                  </p>
                  <h3 className="text-xl font-bold font-display text-[#1F2421]">
                    {service.title}
                  </h3>
                  <p className="mt-2 text-sm text-[#4E5651] leading-relaxed">
                    {service.subtitle}
                  </p>

                  <ul className="mt-5 space-y-2.5 text-sm text-[#1F2421] flex-1">
                    {service.points.map((point) => (
                      <li key={point} className="flex items-start gap-2.5">
                        <Check
                          className="w-4 h-4 text-[#5E7461] shrink-0 mt-0.5"
                          aria-hidden="true"
                        />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6 pt-5 border-t border-[#EFE8DC]">
                    <button
                      type="button"
                      onClick={() => onNavigate({ page: service.targetPage })}
                      className="inline-flex items-center gap-2 text-sm font-semibold text-[#C85A32] hover:text-[#AB4722] transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#C85A32] rounded-sm"
                    >
                      <span>{service.ctaLabel}</span>
                      <ArrowRight className="w-4 h-4" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Pet Care Guides */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-10">
          <div className="space-y-3 max-w-2xl">
            <p className="text-sm font-medium text-[#5E7461]">
              Pet Care Library
            </p>
            <h2 className="text-3xl sm:text-4xl font-bold font-display tracking-tight text-[#1F2421]">
              Practical guides written for clarity
            </h2>
          </div>

          <button
            type="button"
            onClick={() => onNavigate({ page: 'guides' })}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#C85A32] hover:text-[#AB4722] whitespace-nowrap shrink-0 self-start sm:self-auto"
          >
            <span>Browse all {PET_GUIDES.length} guides</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
          {featuredGuides.map((guide) => (
            <article
              key={guide.id}
              className="group flex flex-col bg-white border border-[#E6DFD2] rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-shadow duration-200"
            >
              <div className="aspect-[4/3] overflow-hidden bg-[#EFE8DC]">
                <SafeImage
                  src={guide.image}
                  alt={guide.imageAlt}
                  className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                />
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-xs text-[#6B736E] mb-2">
                  <span className="font-medium text-[#5E7461]">{guide.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{guide.species}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{guide.readTime}</span>
                </div>

                <h3 className="text-lg font-bold font-display text-[#1F2421] leading-snug">
                  {guide.title}
                </h3>
                <p className="mt-2 text-sm text-[#4E5651] leading-relaxed flex-1">
                  {guide.summary}
                </p>

                <div className="mt-5 pt-4 border-t border-[#EFE8DC]">
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate({ page: 'guides', guideSlug: guide.slug })
                    }
                    className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#1F2421] hover:text-[#C85A32] transition-colors"
                  >
                    <span>Read full guide</span>
                    <ArrowRight className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Sample Pet Adoption Showcase */}
      <section className="bg-[#E8EFE7]/65 border-y border-[#DCE4D9] py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
            <div className="space-y-3 max-w-2xl">
              <p className="text-sm font-medium text-[#5E7461]">
                Sample Adoption Showcase · Demonstration Data
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold font-display tracking-tight text-[#1F2421]">
                Companions waiting for calm homes
              </h2>
            </div>

            <button
              type="button"
              onClick={() => onNavigate({ page: 'adoption' })}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-[#1F2421] bg-white border border-[#D4DDD1] hover:border-[#5E7461] rounded-xl transition-colors whitespace-nowrap shrink-0 self-start lg:self-auto"
            >
              <span>View All Sample Profiles</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>

          <div className="mb-8 flex items-start gap-2.5 p-4 rounded-2xl bg-white/80 border border-[#D4DDD1] text-xs sm:text-sm text-[#4E5651]">
            <Info className="w-4 h-4 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
            <p>
              <strong>Sample Profiles Notice:</strong> These dog and cat profiles demonstrate how Paws &amp; Care structures adoption listings. Real-time adoption availability requires connecting to a live partner shelter feed.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
            {featuredPets.map((pet) => (
              <article
                key={pet.id}
                className="flex flex-col bg-white border border-[#DCE4D9] rounded-3xl overflow-hidden shadow-xs"
              >
                <div className="aspect-[4/3] overflow-hidden bg-[#EFE8DC]">
                  <SafeImage
                    src={pet.image}
                    alt={pet.imageAlt}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <div className="flex items-center gap-2 text-xs text-[#6B736E] mb-1.5">
                    <span className="font-medium text-[#5E7461]">Sample Profile</span>
                    <span aria-hidden="true">·</span>
                    <span>{pet.species}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{pet.age}</span>
                  </div>
                  <h3 className="text-xl font-bold font-display text-[#1F2421]">
                    {pet.name}
                  </h3>
                  <p className="text-xs text-[#6B736E] mt-0.5">{pet.breed}</p>
                  <p className="mt-3 text-sm text-[#4E5651] leading-relaxed flex-1">
                    {pet.description}
                  </p>
                  <div className="mt-5 pt-4 border-t border-[#EFE8DC]">
                    <button
                      type="button"
                      onClick={() => onSelectPetForAdoption(pet)}
                      className="w-full inline-flex items-center justify-center px-4 py-2.5 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
                    >
                      Interested in Adoption
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom Call-to-Action Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="bg-[#1F2421] text-white rounded-3xl p-8 sm:p-12 lg:p-14 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div className="space-y-3 max-w-2xl">
            <p className="text-sm font-medium text-[#E8EFE7]">
              Questions about daily pet routines?
            </p>
            <h2 className="text-2xl sm:text-3xl font-bold font-display tracking-tight">
              Reach out to our care desk or explore our editorial mission
            </h2>
            <p className="text-sm sm:text-base text-[#D6D3CD] leading-relaxed">
              Whether you are preparing for your very first kitten or adapting meals for a senior dog, we are here to help you navigate everyday care with confidence.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate({ page: 'contact' })}
              className="px-6 py-3 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              Contact Us
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'about' })}
              className="px-6 py-3 text-sm font-semibold text-white border border-white/25 hover:bg-white/10 rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              About Paws &amp; Care
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
