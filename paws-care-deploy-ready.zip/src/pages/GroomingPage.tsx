import { useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';
import { IMAGES } from '../data/petCareData';
import type { RouteState } from '../utils/petCareLogic';
import { SafeImage } from '../components/SafeImage';

interface GroomingPageProps {
  onNavigate: (route: RouteState) => void;
}

type CoatType = 'Short & Smooth' | 'Double Coat' | 'Long & Curly';

const COAT_ROUTINES: Record<
  CoatType,
  {
    brushing: string;
    bathing: string;
    tools: string;
    tip: string;
  }
> = {
  'Short & Smooth': {
    brushing: '1–2 times per week to lift loose dander and distribute skin oils.',
    bathing: 'Every 6–8 weeks unless muddy; frequent washing dries natural coat oils.',
    tools: 'Soft rubber curry brush or natural boar-bristle glove.',
    tip: 'Wipe paws and belly with a damp warm cloth after dusty walks between baths.',
  },
  'Double Coat': {
    brushing: '3–4 times per week, and daily during spring/autumn undercoat shed.',
    bathing: 'Every 6–8 weeks with lukewarm water; dry thoroughly down to the skin.',
    tools: 'Wide-tooth metal comb plus gentle slicker brush (avoid shaving double coats).',
    tip: 'Line-brush small sections at a time rather than skimming only the top layer.',
  },
  'Long & Curly': {
    brushing: 'Daily or every second day, focusing on ears, collar, and leg feathering.',
    bathing: 'Every 4–6 weeks followed by gentle conditioning spray and towel blotting.',
    tools: 'Pin brush, stainless steel greyhound comb, and detangling mist.',
    tip: 'Always comb out knots completely before getting the coat wet—water locks mats tight.',
  },
};

const HYGIENE_PILLARS = [
  {
    title: '01. Calm Bathing Routine',
    description:
      'Place a non-slip mat in the tub, use lukewarm water, shield ear canals from direct spray, and rinse twice as long as you lathered.',
  },
  {
    title: '02. Stress-Free Nail Trimming',
    description:
      'Trim just the curved tip every 2–3 weeks in bright light. Pair each paw touch with a treat—stopping early beats rushing a full trim.',
  },
  {
    title: '03. Daily Dental Hygiene',
    description:
      'Brush outer tooth surfaces 3–7 times weekly using enzymatic pet toothpaste (never human fluoride paste) to slow tartar and gum inflammation.',
  },
];

export function GroomingPage({ onNavigate }: GroomingPageProps) {
  const [coatType, setCoatType] = useState<CoatType>('Short & Smooth');
  const currentCoat = COAT_ROUTINES[coatType];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 space-y-16">
      {/* Intro Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center space-y-5">
          <p className="text-sm font-medium text-[#5E7461]">Grooming &amp; Hygiene</p>
          <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421] leading-tight">
            Gentle routines for healthy coats, paws, and teeth.
          </h1>
          <p className="text-base text-[#4E5651] leading-relaxed">
            Grooming is more than appearance—regular brushing, paw checks, and tooth brushing let you notice skin bumps, ear redness, or sore gums early while keeping your companion comfortable.
          </p>
          <div className="pt-1 flex flex-wrap gap-4">
            <button
              type="button"
              onClick={() =>
                onNavigate({ page: 'guides', guideSlug: 'dog-grooming-tips' })
              }
              className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
            >
              <span>Read Dog Grooming Guide</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[280px] lg:min-h-[380px] rounded-3xl overflow-hidden border border-[#E6DFD2]">
            <SafeImage
              src={IMAGES.groomingBath}
              alt="Curly puppy wrapped in a soft sage towel after a gentle bath"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Interactive Coat Selector */}
      <section className="bg-white border border-[#E6DFD2] rounded-3xl p-6 sm:p-10 space-y-8 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <p className="text-sm font-medium text-[#5E7461]">Coat Care Planner</p>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-[#1F2421]">
              Tailor brushing &amp; bathing to coat type
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Select coat type"
            className="flex flex-wrap items-center gap-1 p-1 bg-[#F3EDE2] rounded-xl self-start"
          >
            {(['Short & Smooth', 'Double Coat', 'Long & Curly'] as CoatType[]).map(
              (type) => (
                <button
                  key={type}
                  type="button"
                  role="tab"
                  aria-selected={coatType === type}
                  onClick={() => setCoatType(type)}
                  className={`px-3.5 py-2 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                    coatType === type
                      ? 'bg-white text-[#1F2421] shadow-xs'
                      : 'text-[#4E5651] hover:text-[#1F2421]'
                  }`}
                >
                  {type}
                </button>
              ),
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-[#FBF9F5] border border-[#E6DFD2] space-y-2">
            <h3 className="text-sm font-semibold text-[#5E7461]">Brushing Cadence</h3>
            <p className="text-base font-medium text-[#1F2421] leading-relaxed">
              {currentCoat.brushing}
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-[#FBF9F5] border border-[#E6DFD2] space-y-2">
            <h3 className="text-sm font-semibold text-[#5E7461]">Bathing Frequency</h3>
            <p className="text-base font-medium text-[#1F2421] leading-relaxed">
              {currentCoat.bathing}
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-[#FBF9F5] border border-[#E6DFD2] space-y-2">
            <h3 className="text-sm font-semibold text-[#5E7461]">Recommended Tools</h3>
            <p className="text-base font-medium text-[#1F2421] leading-relaxed">
              {currentCoat.tools}
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-[#E8EFE7]/70 border border-[#D4DDD1] space-y-2">
            <h3 className="text-sm font-semibold text-[#5E7461]">Key Handling Tip</h3>
            <p className="text-base font-medium text-[#1F2421] leading-relaxed">
              {currentCoat.tip}
            </p>
          </div>
        </div>
      </section>

      {/* Three Hygiene Pillars */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-7">
        {HYGIENE_PILLARS.map((pillar) => (
          <div
            key={pillar.title}
            className="bg-white border border-[#E6DFD2] rounded-3xl p-7 space-y-3 shadow-xs"
          >
            <div className="w-9 h-9 rounded-xl bg-[#E8EFE7] text-[#5E7461] flex items-center justify-center">
              <Check className="w-4 h-4" aria-hidden="true" />
            </div>
            <h2 className="text-lg font-bold font-display text-[#1F2421]">
              {pillar.title}
            </h2>
            <p className="text-sm text-[#4E5651] leading-relaxed">
              {pillar.description}
            </p>
          </div>
        ))}
      </section>
    </div>
  );
}
