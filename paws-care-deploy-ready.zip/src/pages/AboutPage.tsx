import { ArrowRight, BookOpen, HeartHandshake, ShieldCheck } from 'lucide-react';
import { IMAGES } from '../data/petCareData';
import type { RouteState } from '../utils/petCareLogic';
import { SafeImage } from '../components/SafeImage';

interface AboutPageProps {
  onNavigate: (route: RouteState) => void;
}

const PRINCIPLES = [
  {
    icon: ShieldCheck,
    title: 'Evidence-First Guidance',
    description:
      'Every health, nutrition, and grooming checklist avoids fads and focuses on clear, veterinary-aligned fundamentals.',
  },
  {
    icon: HeartHandshake,
    title: 'Force-Free & Low-Stress',
    description:
      'We advocate cooperative handling, patience, and positive reinforcement rather than harsh corrections or rushed routines.',
  },
  {
    icon: BookOpen,
    title: 'Plain-Language Clarity',
    description:
      'Pet guardians should never have to decode dense clinical jargon just to check a feeding guideline or vaccine schedule.',
  },
];

export function AboutPage({ onNavigate }: AboutPageProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 space-y-16">
      {/* Intro Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center space-y-5">
          <p className="text-sm font-medium text-[#5E7461]">About Paws &amp; Care</p>
          <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421] leading-tight">
            Practical pet care built on warmth and clarity.
          </h1>
          <p className="text-base text-[#4E5651] leading-relaxed">
            Paws &amp; Care was created to give new and experienced pet guardians a calm, trustworthy place to learn everyday care—without sensational headlines, noisy ads, or confusing advice.
          </p>
          <p className="text-base text-[#4E5651] leading-relaxed">
            From your companion&apos;s first week at home through their senior years, our editorial library focuses on preventive habits: balanced nutrition, gentle grooming, early symptom awareness, and ethical adoption practices.
          </p>
          <div className="pt-2 flex flex-wrap gap-4">
            <button
              type="button"
              onClick={() => onNavigate({ page: 'guides' })}
              className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
            >
              <span>Read Care Guides</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'contact' })}
              className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-[#1F2421] bg-white border border-[#D8CFC0] hover:border-[#C85A32]/50 rounded-xl transition-colors"
            >
              <span>Get in Touch</span>
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[300px] lg:min-h-[420px] rounded-3xl overflow-hidden border border-[#E6DFD2]">
            <SafeImage
              src={IMAGES.healthVet}
              alt="Veterinarian gently examining a Beagle in a warm sunlit room"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Core Principles */}
      <section className="space-y-8">
        <div className="space-y-2 max-w-2xl">
          <p className="text-sm font-medium text-[#5E7461]">Our Editorial Standards</p>
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-[#1F2421]">
            How we approach every care recommendation
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
          {PRINCIPLES.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="bg-white border border-[#E6DFD2] rounded-3xl p-7 space-y-3 shadow-xs"
              >
                <div className="w-10 h-10 rounded-xl bg-[#E8EFE7] text-[#5E7461] flex items-center justify-center">
                  <Icon className="w-5 h-5" aria-hidden="true" />
                </div>
                <h3 className="text-lg font-bold font-display text-[#1F2421]">
                  {item.title}
                </h3>
                <p className="text-sm text-[#4E5651] leading-relaxed">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Editorial Team & Scope */}
      <section className="bg-[#F3EDE2] border border-[#E6DFD2] rounded-3xl p-8 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-7 space-y-4">
          <p className="text-sm font-medium text-[#5E7461]">Scope &amp; Medical Transparency</p>
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-[#1F2421]">
            Designed to complement—never replace—your local veterinarian
          </h2>
          <p className="text-sm sm:text-base text-[#4E5651] leading-relaxed">
            Our articles and checklists prepare you for smarter veterinary conversations and calmer daily care at home. Whenever a pet shows acute pain, sudden appetite loss, or breathing changes, consult a licensed clinic directly.
          </p>
        </div>
        <div className="lg:col-span-5 bg-white border border-[#E6DFD2] rounded-2xl p-6 space-y-3 text-sm">
          <h3 className="font-bold font-display text-[#1F2421]">Review Contributors</h3>
          <ul className="space-y-2 text-[#4E5651]">
            <li>Dr. Hannah Reed, DVM · Preventive Care Reviewer</li>
            <li>Maya Lin · Companion Nutrition Advisor</li>
            <li>Samira Patel · Certified Fear-Free Groomer</li>
            <li>Jordan Ellis · Force-Free Behaviour Consultant</li>
          </ul>
        </div>
      </section>
    </div>
  );
}
