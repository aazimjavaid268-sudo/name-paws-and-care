import { useState, type FormEvent } from 'react';
import { CheckCircle2, Info, Mail, MapPin, Phone, User } from 'lucide-react';
import { validateContactForm } from '../utils/petCareLogic';

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [petType, setPetType] = useState('Dog');
  const [topic, setTopic] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const result = validateContactForm({
      name,
      email,
      petType,
      topic,
      message,
    });

    if (!result.valid) {
      setErrors(result.errors);
      return;
    }

    setErrors({});
    setSubmitted(true);
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setPetType('Dog');
    setTopic('');
    setMessage('');
    setErrors({});
    setSubmitted(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 space-y-12">
      <div className="space-y-4 max-w-2xl">
        <p className="text-sm font-medium text-[#5E7461]">Contact Us</p>
        <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-[#1F2421]">
          Questions about pet care or our guides?
        </h1>
        <p className="text-base text-[#4E5651] leading-relaxed">
          Send a note to our editorial care desk. Every field is validated before submission so your inquiry stays clear and actionable.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Form Card */}
        <div className="lg:col-span-7 bg-white border border-[#E6DFD2] rounded-3xl p-6 sm:p-10 shadow-xs">
          {submitted ? (
            <div className="py-6 text-center space-y-4">
              <CheckCircle2
                className="w-12 h-12 text-[#5E7461] mx-auto"
                aria-hidden="true"
              />
              <h2 className="text-2xl font-bold font-display text-[#1F2421]">
                Message Validated &amp; Ready
              </h2>
              <p className="text-sm sm:text-base text-[#4E5651] max-w-md mx-auto leading-relaxed">
                Thank you, <strong>{name}</strong>. Your inquiry regarding{' '}
                <strong>{topic}</strong> has passed validation. Because this is a static frontend build, connect a form service (such as Netlify Forms, Formspree, or an Express API route) to deliver emails live.
              </p>
              <button
                type="button"
                onClick={handleReset}
                className="inline-flex items-center justify-center px-5 py-2.5 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-sm font-medium text-[#1F2421] mb-1.5"
                  >
                    Full Name
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Clara Bennett"
                    className="w-full px-4 py-2.5 text-sm bg-[#FBF9F5] border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
                  />
                  {errors.name && (
                    <p className="mt-1.5 text-xs text-[#B93822]">{errors.name}</p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="contact-email"
                    className="block text-sm font-medium text-[#1F2421] mb-1.5"
                  >
                    Email Address
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="clara@example.com"
                    className="w-full px-4 py-2.5 text-sm bg-[#FBF9F5] border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
                  />
                  {errors.email && (
                    <p className="mt-1.5 text-xs text-[#B93822]">{errors.email}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label
                    htmlFor="contact-pet"
                    className="block text-sm font-medium text-[#1F2421] mb-1.5"
                  >
                    Companion Type
                  </label>
                  <select
                    id="contact-pet"
                    value={petType}
                    onChange={(e) => setPetType(e.target.value)}
                    className="w-full px-4 py-2.5 text-sm bg-[#FBF9F5] border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
                  >
                    <option value="Dog">Dog</option>
                    <option value="Cat">Cat</option>
                    <option value="Both Dog & Cat">Both Dog &amp; Cat</option>
                    <option value="Planning to Adopt">Planning to Adopt</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="contact-topic"
                    className="block text-sm font-medium text-[#1F2421] mb-1.5"
                  >
                    Topic
                  </label>
                  <select
                    id="contact-topic"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="w-full px-4 py-2.5 text-sm bg-[#FBF9F5] border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
                  >
                    <option value="">Choose a topic</option>
                    <option value="Health & Preventive Care">
                      Health &amp; Preventive Care
                    </option>
                    <option value="Nutrition Guidance">Nutrition Guidance</option>
                    <option value="Grooming Routine">Grooming Routine</option>
                    <option value="Sample Adoption Demo">Sample Adoption Demo</option>
                    <option value="Guide Suggestion">Guide Suggestion</option>
                  </select>
                  {errors.topic && (
                    <p className="mt-1.5 text-xs text-[#B93822]">{errors.topic}</p>
                  )}
                </div>
              </div>

              <div>
                <label
                  htmlFor="contact-message"
                  className="block text-sm font-medium text-[#1F2421] mb-1.5"
                >
                  Message
                </label>
                <textarea
                  id="contact-message"
                  rows={5}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us about your pet's age, routine, or question..."
                  className="w-full px-4 py-2.5 text-sm bg-[#FBF9F5] border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
                />
                {errors.message && (
                  <p className="mt-1.5 text-xs text-[#B93822]">{errors.message}</p>
                )}
              </div>

              <div className="pt-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <button
                  type="submit"
                  className="px-6 py-3 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors whitespace-nowrap shrink-0"
                >
                  Send Message
                </button>
                <p className="text-xs text-[#6B736E]">
                  Client-side validation active · Static demo submission
                </p>
              </div>
            </form>
          )}
        </div>

        {/* Contact Info & Notice */}
        <aside className="lg:col-span-5 space-y-6">
          <div className="bg-[#F3EDE2] border border-[#E6DFD2] rounded-3xl p-7 space-y-5">
            <h2 className="text-xl font-bold font-display text-[#1F2421]">
              Care Desk Details (Placeholders)
            </h2>
            <ul className="space-y-4 text-sm text-[#4E5651]">
              <li className="flex items-start gap-3">
                <User className="w-5 h-5 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-[#1F2421]">Name</p>
                  <p>Irtija</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-[#1F2421]">Email</p>
                  <p>irtijarashid00@gmail.com</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-[#1F2421]">Phone</p>
                  <p className="tabular-nums">+91 60054 93880</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-[#1F2421]">Location</p>
                  <p>CGC University Mohali, Punjab, India</p>
                </div>
              </li>
            </ul>
          </div>

          <div className="bg-[#E8EFE7]/75 border border-[#D4DDD1] rounded-3xl p-6 flex items-start gap-3 text-sm text-[#4E5651] leading-relaxed">
            <Info className="w-5 h-5 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <strong className="text-[#1F2421]">Medical Emergencies:</strong>{' '}
              Paws &amp; Care cannot provide emergency triage via web forms. If your pet has ingested a toxic substance or has difficulty breathing, contact your nearest 24-hour veterinary hospital immediately.
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
