export type PageId =
  | 'home'
  | 'about'
  | 'health'
  | 'nutrition'
  | 'grooming'
  | 'guides'
  | 'adoption'
  | 'contact';

export interface RouteState {
  page: PageId;
  guideSlug?: string;
}

export type GuideCategory =
  | 'All'
  | 'Beginners'
  | 'Health'
  | 'Nutrition'
  | 'Grooming'
  | 'Behaviour';

export interface GuideSection {
  heading: string;
  paragraphs: string[];
  checklist?: string[];
}

export interface GuideArticle {
  id: string;
  slug: string;
  title: string;
  category: Exclude<GuideCategory, 'All'>;
  species: 'Dogs & Cats' | 'Dogs' | 'Cats';
  readTime: string;
  updatedAt: string;
  reviewer: string;
  summary: string;
  image: string;
  imageAlt: string;
  keyTakeaways: string[];
  sections: GuideSection[];
}

export type PetSpeciesFilter = 'All' | 'Dog' | 'Cat';

export interface AdoptionPet {
  id: string;
  name: string;
  species: 'Dog' | 'Cat';
  breed: string;
  age: string;
  size: string;
  temperament: string;
  description: string;
  careNote: string;
  vaccinated: boolean;
  microchipped: boolean;
  image: string;
  imageAlt: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  petType: string;
  topic: string;
  message: string;
}

export interface AdoptionInquiryData {
  petId: string;
  petName: string;
  applicantName: string;
  email: string;
  phone: string;
  homeType: string;
  experience: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

const VALID_PAGES: ReadonlySet<PageId> = new Set([
  'home',
  'about',
  'health',
  'nutrition',
  'grooming',
  'guides',
  'adoption',
  'contact',
]);

export function parseRouteFromHash(hash: string): RouteState {
  const cleaned = hash.replace(/^#\/?/, '').trim();
  if (!cleaned) {
    return { page: 'home' };
  }

  const parts = cleaned.split('/').filter(Boolean);
  const first = parts[0]?.toLowerCase() as PageId | undefined;

  if (first === 'guides' && parts[1]) {
    return { page: 'guides', guideSlug: parts[1] };
  }

  if (first && VALID_PAGES.has(first)) {
    return { page: first };
  }

  return { page: 'home' };
}

export function buildHashForRoute(route: RouteState): string {
  if (route.page === 'home') {
    return '#home';
  }
  if (route.page === 'guides' && route.guideSlug) {
    return `#guides/${route.guideSlug}`;
  }
  return `#${route.page}`;
}

export function filterGuides(
  guides: readonly GuideArticle[],
  category: GuideCategory,
  query: string,
): GuideArticle[] {
  const normalizedQuery = query.trim().toLowerCase();

  return guides.filter((guide) => {
    const matchesCategory = category === 'All' || guide.category === category;
    if (!matchesCategory) {
      return false;
    }

    if (!normalizedQuery) {
      return true;
    }

    const haystack = [
      guide.title,
      guide.summary,
      guide.category,
      guide.species,
      ...guide.keyTakeaways,
      ...guide.sections.flatMap((s) => [s.heading, ...s.paragraphs]),
    ]
      .join(' ')
      .toLowerCase();

    return haystack.includes(normalizedQuery);
  });
}

export function filterPets(
  pets: readonly AdoptionPet[],
  species: PetSpeciesFilter,
): AdoptionPet[] {
  if (species === 'All') {
    return [...pets];
  }
  return pets.filter((pet) => pet.species === species);
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_REGEX = /^[+\d()\s-]{7,20}$/;

export function validateContactForm(data: ContactFormData): ValidationResult {
  const errors: Record<string, string> = {};

  if (!data.name.trim() || data.name.trim().length < 2) {
    errors.name = 'Please enter your full name (at least 2 characters).';
  }

  if (!EMAIL_REGEX.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }

  if (!data.topic.trim()) {
    errors.topic = 'Please select an inquiry topic.';
  }

  if (!data.message.trim() || data.message.trim().length < 15) {
    errors.message = 'Please share a brief message (at least 15 characters).';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function validateAdoptionInquiry(data: AdoptionInquiryData): ValidationResult {
  const errors: Record<string, string> = {};

  if (!data.applicantName.trim() || data.applicantName.trim().length < 2) {
    errors.applicantName = 'Please enter your full name.';
  }

  if (!EMAIL_REGEX.test(data.email.trim())) {
    errors.email = 'Please provide a valid email address.';
  }

  if (!PHONE_REGEX.test(data.phone.trim())) {
    errors.phone = 'Please provide a valid phone number (7 to 20 digits).';
  }

  if (!data.homeType.trim()) {
    errors.homeType = 'Please select your living environment.';
  }

  if (!data.experience.trim() || data.experience.trim().length < 12) {
    errors.experience = 'Please briefly describe your household or pet experience.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}
