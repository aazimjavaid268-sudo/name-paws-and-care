import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildHashForRoute,
  filterGuides,
  filterPets,
  parseRouteFromHash,
  validateAdoptionInquiry,
  validateContactForm,
} from './petCareLogic';
import { ADOPTION_PETS, PET_GUIDES } from '../data/petCareData';

test('parseRouteFromHash resolves home, pages, and guide slugs', () => {
  assert.deepEqual(parseRouteFromHash(''), { page: 'home' });
  assert.deepEqual(parseRouteFromHash('#health'), { page: 'health' });
  assert.deepEqual(parseRouteFromHash('#/nutrition'), { page: 'nutrition' });
  assert.deepEqual(parseRouteFromHash('#guides/beginners-guide-to-owning-a-pet'), {
    page: 'guides',
    guideSlug: 'beginners-guide-to-owning-a-pet',
  });
  assert.deepEqual(parseRouteFromHash('#unknown-route'), { page: 'home' });
});

test('buildHashForRoute builds canonical hashes', () => {
  assert.equal(buildHashForRoute({ page: 'home' }), '#home');
  assert.equal(buildHashForRoute({ page: 'adoption' }), '#adoption');
  assert.equal(
    buildHashForRoute({ page: 'guides', guideSlug: 'cat-care-essentials' }),
    '#guides/cat-care-essentials',
  );
});

test('filterGuides filters by category and search query accurately', () => {
  const all = filterGuides(PET_GUIDES, 'All', '');
  assert.equal(all.length, PET_GUIDES.length);

  const groomingOnly = filterGuides(PET_GUIDES, 'Grooming', '');
  assert.ok(groomingOnly.length >= 1);
  assert.ok(groomingOnly.every((g) => g.category === 'Grooming'));

  const catSearch = filterGuides(PET_GUIDES, 'All', 'cat');
  assert.ok(catSearch.some((g) => g.slug === 'cat-care-essentials'));

  const emptySearch = filterGuides(PET_GUIDES, 'Nutrition', 'nonexistent-keyword-xyz');
  assert.equal(emptySearch.length, 0);
});

test('filterPets filters sample adoption profiles by species', () => {
  const all = filterPets(ADOPTION_PETS, 'All');
  const dogs = filterPets(ADOPTION_PETS, 'Dog');
  const cats = filterPets(ADOPTION_PETS, 'Cat');

  assert.equal(all.length, ADOPTION_PETS.length);
  assert.ok(dogs.length >= 2);
  assert.ok(cats.length >= 2);
  assert.ok(dogs.every((p) => p.species === 'Dog'));
  assert.ok(cats.every((p) => p.species === 'Cat'));
});

test('validateContactForm rejects invalid inputs and accepts valid submissions', () => {
  const invalid = validateContactForm({
    name: 'A',
    email: 'not-an-email',
    petType: 'Dog',
    topic: '',
    message: 'Hi',
  });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.name);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.topic);
  assert.ok(invalid.errors.message);

  const valid = validateContactForm({
    name: 'Clara Bennett',
    email: 'clara@example.com',
    petType: 'Cat',
    topic: 'Nutrition Guidance',
    message: 'Looking for feeding schedule tips for a 6-month-old indoor kitten.',
  });
  assert.equal(valid.valid, true);
  assert.deepEqual(valid.errors, {});
});

test('validateAdoptionInquiry validates applicant fields strictly', () => {
  const invalid = validateAdoptionInquiry({
    petId: 'pet-1',
    petName: 'Milo',
    applicantName: '',
    email: 'bad',
    phone: '12',
    homeType: '',
    experience: 'short',
  });
  assert.equal(invalid.valid, false);
  assert.equal(Object.keys(invalid.errors).length, 5);

  const valid = validateAdoptionInquiry({
    petId: 'pet-1',
    petName: 'Milo',
    applicantName: 'David Park',
    email: 'david.park@example.com',
    phone: '+1 (503) 555-0194',
    homeType: 'House with fenced yard',
    experience: 'Previously raised two rescued dogs and work mostly from home.',
  });
  assert.equal(valid.valid, true);
});
