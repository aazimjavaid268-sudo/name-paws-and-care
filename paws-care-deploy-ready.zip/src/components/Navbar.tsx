import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import type { PageId, RouteState } from '../utils/petCareLogic';

interface NavbarProps {
  currentPage: PageId;
  onNavigate: (route: RouteState) => void;
}

const CENTER_LINKS: { label: string; page: PageId }[] = [
  { label: 'Home', page: 'home' },
  { label: 'Pet Care', page: 'guides' },
  { label: 'Health', page: 'health' },
  { label: 'Nutrition', page: 'nutrition' },
  { label: 'Grooming', page: 'grooming' },
  { label: 'Adoption', page: 'adoption' },
  { label: 'About', page: 'about' },
];

const MOBILE_LINKS: { label: string; page: PageId }[] = [
  { label: 'Home', page: 'home' },
  { label: 'About Us', page: 'about' },
  { label: 'Pet Health', page: 'health' },
  { label: 'Pet Nutrition', page: 'nutrition' },
  { label: 'Grooming', page: 'grooming' },
  { label: 'Pet Care Guides', page: 'guides' },
  { label: 'Pet Adoption', page: 'adoption' },
  { label: 'Contact Us', page: 'contact' },
];

export function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && mobileOpen) {
        setMobileOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [mobileOpen]);

  const handleLinkClick = (page: PageId) => {
    setMobileOpen(false);
    onNavigate({ page });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FBF9F5]/95 backdrop-blur-sm border-b border-[#E6DFD2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            handleLinkClick('home');
          }}
          className="inline-flex items-center gap-2.5 text-lg font-bold font-display tracking-tight text-[#1F2421] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#C85A32] rounded-md"
        >
          <svg
            viewBox="0 0 28 28"
            className="w-6 h-6 text-[#C85A32] shrink-0"
            fill="currentColor"
            aria-hidden="true"
          >
            <ellipse cx="7.5" cy="9.5" rx="2.3" ry="3" />
            <ellipse cx="14" cy="7" rx="2.3" ry="3" />
            <ellipse cx="20.5" cy="9.5" rx="2.3" ry="3" />
            <path d="M14 12.2c-4.2 0-7.2 3.1-7.2 6.3 0 2.1 1.6 3.5 3.8 3.5 1.3 0 2.3-.5 3.4-.5s2.1.5 3.4.5c2.2 0 3.8-1.4 3.8-3.5 0-3.2-3-6.3-7.2-6.3Z" />
          </svg>
          <span>Paws &amp; Care</span>
        </a>

        {/* Zone 2: Primary Desktop Navigation Links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden lg:flex items-center gap-6"
        >
          {CENTER_LINKS.map((item) => {
            const active = currentPage === item.page;
            return (
              <a
                key={item.page}
                href={`#${item.page}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(item.page);
                }}
                aria-current={active ? 'page' : undefined}
                className={`relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#C85A32] rounded-sm ${
                  active
                    ? 'text-[#1F2421]'
                    : 'text-[#4E5651] hover:text-[#1F2421]'
                }`}
              >
                {item.label}
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute left-0 right-0 -bottom-0.5 h-0.5 bg-[#C85A32] rounded-full"
                  />
                )}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action + Mobile Menu Trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="#contact"
            onClick={(e) => {
              e.preventDefault();
              handleLinkClick('contact');
            }}
            aria-current={currentPage === 'contact' ? 'page' : undefined}
            className="hidden lg:inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C85A32]"
          >
            Contact
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-navigation-drawer"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="lg:hidden inline-flex items-center justify-center w-11 h-11 rounded-xl text-[#1F2421] hover:bg-[#F3EDE2] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C85A32]"
          >
            {mobileOpen ? (
              <X className="w-5 h-5" aria-hidden="true" />
            ) : (
              <Menu className="w-5 h-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <nav
          id="mobile-navigation-drawer"
          aria-label="Mobile Navigation"
          className="lg:hidden border-t border-[#E6DFD2] bg-[#FBF9F5] px-4 py-4 shadow-sm"
        >
          <ul className="flex flex-col gap-1">
            {MOBILE_LINKS.map((item) => {
              const active = currentPage === item.page;
              return (
                <li key={item.page}>
                  <a
                    href={`#${item.page}`}
                    onClick={(e) => {
                      e.preventDefault();
                      handleLinkClick(item.page);
                    }}
                    aria-current={active ? 'page' : undefined}
                    className={`flex items-center justify-between min-h-11 px-4 py-2.5 rounded-xl text-base font-medium transition-colors ${
                      active
                        ? 'bg-[#F3EDE2] text-[#C85A32] font-semibold'
                        : 'text-[#1F2421] hover:bg-[#F3EDE2]/70'
                    }`}
                  >
                    <span>{item.label}</span>
                  </a>
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </header>
  );
}
