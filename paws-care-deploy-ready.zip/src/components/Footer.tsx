import { Mail, MapPin, Phone, User } from 'lucide-react';
import type { PageId, RouteState } from '../utils/petCareLogic';

interface FooterProps {
  onNavigate: (route: RouteState) => void;
}

const QUICK_LINKS: { label: string; page: PageId }[] = [
  { label: 'Home', page: 'home' },
  { label: 'About Us', page: 'about' },
  { label: 'Pet Health', page: 'health' },
  { label: 'Pet Nutrition', page: 'nutrition' },
  { label: 'Grooming', page: 'grooming' },
  { label: 'Pet Care Guides', page: 'guides' },
  { label: 'Pet Adoption', page: 'adoption' },
  { label: 'Contact Us', page: 'contact' },
];

const GUIDE_CATEGORIES: { label: string; slug: string }[] = [
  { label: "Beginner's Pet Guide", slug: 'beginners-guide-to-owning-a-pet' },
  { label: 'Preventive Health', slug: 'how-to-maintain-your-pets-health' },
  { label: 'Feeding & Nutrition', slug: 'best-feeding-practices' },
  { label: 'Dog Grooming Tips', slug: 'dog-grooming-tips' },
  { label: 'Cat Care Essentials', slug: 'cat-care-essentials' },
  { label: 'Pet Behaviour', slug: 'understanding-pet-behaviour' },
];

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-[#F3EDE2] border-t border-[#E6DFD2] text-[#1F2421]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Brand Summary */}
          <div className="lg:col-span-4 space-y-4">
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                onNavigate({ page: 'home' });
              }}
              className="inline-flex items-center gap-2.5 text-lg font-bold font-display tracking-tight text-[#1F2421]"
            >
              <svg
                viewBox="0 0 28 28"
                className="w-6 h-6 text-[#C85A32]"
                fill="currentColor"
                aria-hidden="true"
              >
                <ellipse cx="7.5" cy="9.5" rx="2.3" ry="3" />
                <ellipse cx="14" cy="7" rx="2.3" ry="3" />
                <ellipse cx="20.5" cy="9.5" rx="2.3" ry="3" />
                <path d="M14 12.2c-4.2 0-7.2 3.1-7.2 6.3 0 2.1 1.6 3.5 3.8 3.5 1.3 0 2.3-.5 3.4-.5s2.1.5 3.4.5c2.2 0 3.8-1.4 3.8-3.5 0-3.2-3-6.3-7.2-6.3Z" />
              </svg>
              <span>Paws &amp; Care</span>
            </a>
            <p className="text-sm leading-relaxed text-[#4E5651] max-w-sm">
              Thoughtful, vet-reviewed care guidance helping dog and cat guardians build calmer, healthier daily routines with their companions.
            </p>
            <div className="flex items-center gap-5 pt-1 text-sm font-medium text-[#4E5651]">
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate({ page: 'contact' });
                }}
                aria-label="Instagram community updates via Contact page"
                className="hover:text-[#C85A32] transition-colors"
              >
                Instagram
              </a>
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate({ page: 'contact' });
                }}
                aria-label="YouTube care tutorials via Contact page"
                className="hover:text-[#C85A32] transition-colors"
              >
                YouTube
              </a>
              <a
                href="#guides"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate({ page: 'guides' });
                }}
                aria-label="Care Newsletter and Guides"
                className="hover:text-[#C85A32] transition-colors"
              >
                Journal
              </a>
            </div>
          </div>

          {/* Quick Navigation */}
          <div className="lg:col-span-3 space-y-3">
            <h2 className="text-sm font-semibold font-display text-[#1F2421]">
              Quick Links
            </h2>
            <ul className="grid grid-cols-2 lg:grid-cols-1 gap-2 text-sm text-[#4E5651]">
              {QUICK_LINKS.map((item) => (
                <li key={item.page}>
                  <a
                    href={`#${item.page}`}
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate({ page: item.page });
                    }}
                    className="hover:text-[#C85A32] transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Pet Care Categories */}
          <div className="lg:col-span-2 space-y-3">
            <h2 className="text-sm font-semibold font-display text-[#1F2421]">
              Care Guides
            </h2>
            <ul className="space-y-2 text-sm text-[#4E5651]">
              {GUIDE_CATEGORIES.map((item) => (
                <li key={item.slug}>
                  <a
                    href={`#guides/${item.slug}`}
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate({ page: 'guides', guideSlug: item.slug });
                    }}
                    className="hover:text-[#C85A32] transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Placeholders */}
          <div className="lg:col-span-3 space-y-3">
            <h2 className="text-sm font-semibold font-display text-[#1F2421]">
              Care Desk (Sample Contact)
            </h2>
            <ul className="space-y-2.5 text-sm text-[#4E5651]">
              <li className="flex items-start gap-2.5">
                <User className="w-4 h-4 mt-0.5 text-[#5E7461] shrink-0" aria-hidden="true" />
                <span>Irtija</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 mt-0.5 text-[#5E7461] shrink-0" aria-hidden="true" />
                <span>irtijarashid00@gmail.com</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 mt-0.5 text-[#5E7461] shrink-0" aria-hidden="true" />
                <span className="tabular-nums">+91 60054 93880</span>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 mt-0.5 text-[#5E7461] shrink-0" aria-hidden="true" />
                <span>CGC University Mohali, Punjab, India</span>
              </li>
            </ul>
            <p className="text-xs text-[#6B736E] pt-1 leading-relaxed">
              Educational guidance only—always consult a licensed veterinarian for urgent medical concerns.
            </p>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-[#E0D7C8] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#6B736E]">
          <p>&copy; 2026 Paws &amp; Care. All rights reserved.</p>
          <p>
            Sample adoption listings and contact details are provided for demonstration.
          </p>
        </div>
      </div>
    </footer>
  );
}
