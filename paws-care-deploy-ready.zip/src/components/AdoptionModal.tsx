import { useEffect, useState, type FormEvent } from 'react';
import { CheckCircle2, Info, X } from 'lucide-react';
import {
  validateAdoptionInquiry,
  type AdoptionPet,
} from '../utils/petCareLogic';
import { SafeImage } from './SafeImage';

interface AdoptionModalProps {
  pet: AdoptionPet | null;
  onClose: () => void;
}

export function AdoptionModal({ pet, onClose }: AdoptionModalProps) {
  const [applicantName, setApplicantName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [homeType, setHomeType] = useState('');
  const [experience, setExperience] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!pet) return;
    setErrors({});
    setSubmitted(false);

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [pet, onClose]);

  if (!pet) {
    return null;
  }

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const result = validateAdoptionInquiry({
      petId: pet.id,
      petName: pet.name,
      applicantName,
      email,
      phone,
      homeType,
      experience,
    });

    if (!result.valid) {
      setErrors(result.errors);
      return;
    }

    setErrors({});
    setSubmitted(true);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="adoption-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1F2421]/50 backdrop-blur-xs"
    >
      <div className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-[#FBF9F5] border border-[#E6DFD2] rounded-3xl shadow-xl p-6 sm:p-8">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close adoption inquiry dialog"
          className="absolute top-5 right-5 inline-flex items-center justify-center w-10 h-10 rounded-full text-[#4E5651] hover:bg-[#F3EDE2] hover:text-[#1F2421] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C85A32]"
        >
          <X className="w-5 h-5" aria-hidden="true" />
        </button>

        <div className="flex items-center gap-4 pr-10">
          <SafeImage
            src={pet.image}
            alt={pet.imageAlt}
            className="w-16 h-16 rounded-2xl object-cover shrink-0 border border-[#E6DFD2]"
          />
          <div>
            <p className="text-xs font-medium text-[#5E7461]">
              Sample Adoption Profile · {pet.species}
            </p>
            <h2
              id="adoption-modal-title"
              className="text-2xl font-bold font-display text-[#1F2421]"
            >
              Inquire About {pet.name}
            </h2>
            <p className="text-sm text-[#4E5651]">
              {pet.breed} · {pet.age}
            </p>
          </div>
        </div>

        <div className="mt-5 flex items-start gap-2.5 p-3.5 rounded-2xl bg-[#E8EFE7] text-[#1F2421] text-xs leading-relaxed">
          <Info className="w-4 h-4 text-[#5E7461] shrink-0 mt-0.5" aria-hidden="true" />
          <span>
            <strong>Demonstration Notice:</strong> {pet.name} is a sample profile for showcase purposes. Connecting live shelter availability requires integrating a partner shelter feed (such as Petfinder API or RescueGroups) and a backend mail endpoint.
          </span>
        </div>

        {submitted ? (
          <div className="mt-6 p-6 rounded-2xl bg-white border border-[#E6DFD2] text-center space-y-3">
            <CheckCircle2
              className="w-10 h-10 text-[#5E7461] mx-auto"
              aria-hidden="true"
            />
            <h3 className="text-lg font-bold font-display text-[#1F2421]">
              Sample Inquiry Validated for {pet.name}
            </h3>
            <p className="text-sm text-[#4E5651] leading-relaxed">
              Thank you, {applicantName}. Your inquiry details passed client-side validation. In a live shelter deployment, this payload would be forwarded to the partner rescue coordinator at <span className="font-medium text-[#1F2421]">{email}</span>.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="mt-2 inline-flex items-center justify-center px-5 py-2.5 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-4">
            <div>
              <label
                htmlFor="adopt-name"
                className="block text-sm font-medium text-[#1F2421] mb-1.5"
              >
                Your Full Name
              </label>
              <input
                id="adopt-name"
                type="text"
                value={applicantName}
                onChange={(e) => setApplicantName(e.target.value)}
                placeholder="e.g. Clara Bennett"
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
              />
              {errors.applicantName && (
                <p className="mt-1 text-xs text-[#B93822]">{errors.applicantName}</p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="adopt-email"
                  className="block text-sm font-medium text-[#1F2421] mb-1.5"
                >
                  Email Address
                </label>
                <input
                  id="adopt-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
                />
                {errors.email && (
                  <p className="mt-1 text-xs text-[#B93822]">{errors.email}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="adopt-phone"
                  className="block text-sm font-medium text-[#1F2421] mb-1.5"
                >
                  Phone Number
                </label>
                <input
                  id="adopt-phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+1 (503) 555-0192"
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
                />
                {errors.phone && (
                  <p className="mt-1 text-xs text-[#B93822]">{errors.phone}</p>
                )}
              </div>
            </div>

            <div>
              <label
                htmlFor="adopt-home"
                className="block text-sm font-medium text-[#1F2421] mb-1.5"
              >
                Living Environment
              </label>
              <select
                id="adopt-home"
                value={homeType}
                onChange={(e) => setHomeType(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
              >
                <option value="">Select your housing type</option>
                <option value="House with fenced yard">House with fenced yard</option>
                <option value="House without fenced yard">House without fenced yard</option>
                <option value="Apartment or condo">Apartment or condo</option>
                <option value="Townhome">Townhome</option>
              </select>
              {errors.homeType && (
                <p className="mt-1 text-xs text-[#B93822]">{errors.homeType}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="adopt-experience"
                className="block text-sm font-medium text-[#1F2421] mb-1.5"
              >
                Household &amp; Pet Experience
              </label>
              <textarea
                id="adopt-experience"
                rows={3}
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                placeholder="Share your daily schedule, other pets, or prior care experience..."
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#D8CFC0] rounded-xl text-[#1F2421] focus:outline-none focus:border-[#C85A32] focus:ring-2 focus:ring-[#C85A32]/20"
              />
              {errors.experience && (
                <p className="mt-1 text-xs text-[#B93822]">{errors.experience}</p>
              )}
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-sm font-medium text-[#4E5651] hover:text-[#1F2421] rounded-xl hover:bg-[#F3EDE2] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#C85A32] hover:bg-[#AB4722] rounded-xl transition-colors"
              >
                Submit Sample Inquiry
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
